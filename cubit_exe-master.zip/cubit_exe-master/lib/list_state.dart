class ListState{
  List<Map<String,dynamic>> mData;
  ListState({required this.mData});
 }